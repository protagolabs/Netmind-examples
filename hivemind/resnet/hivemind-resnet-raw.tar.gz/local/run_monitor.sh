python run_training_monitor.py \
--experiment_prefix resne_experiment \
--wandb_project resnet_wandb \
--arch=resnet50 