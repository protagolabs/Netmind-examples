
## computer vision model training

Fine-tuning (or training from scratch) the computer vision models on netmind with hivemind.