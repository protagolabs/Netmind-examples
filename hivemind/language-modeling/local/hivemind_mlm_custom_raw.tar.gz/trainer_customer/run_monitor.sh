python run_training_monitor.py \
--model_name_or_path bert-base-uncasedcd \
--experiment_prefix bert_experiment \
--wandb_project bert_wandb_4ka